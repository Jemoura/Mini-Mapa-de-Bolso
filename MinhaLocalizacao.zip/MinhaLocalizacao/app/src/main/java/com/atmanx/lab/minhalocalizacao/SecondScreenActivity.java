package com.atmanx.lab.minhalocalizacao;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecondScreenActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_activity);

        Button btn_return = (Button) findViewById(R.id.btn_return);
        TextView tv_lat = (TextView) findViewById(R.id.tv_latitude);
        TextView tv_lng = (TextView) findViewById(R.id.tv_longitude);
        Intent i = getIntent();
        // Receiving the Data
        String lat = i.getStringExtra("lat");
        String lng = i.getStringExtra("lng");
        
        // Displaying Received data
        tv_lat.setText(lat);
        tv_lng.setText(lng);
        
        // Binding Click event to Button
        btn_return.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View arg0) {
				//Closing SecondScreen Activity
				finish();
			}
		});
        
    }
}
